Ext.define('LensControl.view.lens.LensController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.lens',
    init: function () {
        console.log('TestwsController');
        
//        var ws = Ext.create('Ext.ux.WebSocket', {
//            url: "ws://127.0.0.1:7890?login=tango&password=tango",
//            autoReconnect: true ,
//            autoReconnectInterval: 1000,
//            //url: prop.getUrlwstest(),
//            listeners: {
//                open: function (ws) {
//                    console.log('websocket Open');
//                },
//                message: function (ws, data) {
//                    console.log('getting data');                    
//                },
//                close: function (ws) {
//                    console.log ('The websocket is closed!');
//                },
//                error: function (ws, error) {
//                    Ext.Error.raise (error);
//                } ,
//            }
//        });
    }
});

