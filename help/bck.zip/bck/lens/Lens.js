Ext.Loader.setConfig ({
    enabled: true
});

//Ext.require (['Ext.ux.data.proxy.WebSocket']);

Ext.define('LensControl.view.lens.Lens', {
    //extend: 'Ext.grid.Panel',
    extend: 'Ext.form.Panel',
    xtype: 'lens',
    title: 'Источники питания',
    
    requires: [
        'LensControl.view.lens.LensController',
        'LensControl.store.LensWsStore',
        'Ext.ux.data.proxy.WebSocket'
    ],
    
    controller: 'lens',
    
    items: [
    {
        xtype: 'gridpanel',
        collapsible: true,

        store : {
            type: 'lenswsstore'
        },
        columns: [
            {text: 'Регистр/Флаг',flex: 0.3, dataIndex: 'device_name'},
            {text: 'Значение',flex: 0.3, dataIndex: 'device_status'},
            {text: 'Описание',flex: 1, dataIndex: 'device_state'}
        ]
    }    
    ],
});

