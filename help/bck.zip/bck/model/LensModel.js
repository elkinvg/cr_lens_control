Ext.define('LensControl.model.LensModel', {
    extend: 'Ext.data.Model',
    //alias: 'model.lensmodel',
    fields: [
        'timestamp',
        'device_name',
        'device_status',
        'device_state',
        'volt_measure',
        'curr_measure',
        'volt_level',
        'curr_level'
    ],
    proxy: {
        type: 'websocket',
        storeId: 'myStore',
        url: 'ws://127.0.0.1:7890?login=tango&password=tango',
        reader: {
            type: 'json' ,
        }
    }
});


